== Name ==
Advance Member Managment (AMM)

== Description ==
User Can register through the invitation code only. Plugin will generate uniue
invitation code for each user. User can share that invitation code to other users through which other user can register

== Admin ===
By default when plugin activate at that time , it will generate invitation code for Admin.
Admin can generate and update invitaiton code by settings page.
Admin can set number of invitations and invitation code method
Admin can make member status approve

== Shortcodes == 
[amm_invitation_code] - display current logged in user invitation code
[amm_view_invited_users] - display all users list who comes and register to site through
                           current user logged in invitation code  
[amm_register_form] - To display register form. if user is already logged in then it     
                      will not show the form
[amm_invited_by] - it will show by which user you are invited and by which invitation code
[amm_login] - Login Shortcode	
[amm_profile] - to edit profile		
[amm_lost_passowrd] - Page for lost password form	
[amm_referaal_list] - to list referaals	  
[amm_user_name] - display user name
