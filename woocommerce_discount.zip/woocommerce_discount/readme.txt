== Name ==
Woo Commerce Discount Extension

== Description ==
It will work with woocommerce only. 
Admin have configuration page in which he can set discount percentage
and discount point

When user purchase product then per order he will get discount based on settings
and that discount will cut from his discount point

